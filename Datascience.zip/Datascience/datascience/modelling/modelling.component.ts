import { Component, OnInit, OnDestroy , ViewChild,AfterViewInit,ChangeDetectionStrategy,ChangeDetectorRef } from "@angular/core";
import { Router , ActivatedRoute} from "@angular/router";
import { PdffilesService } from "src/app/Services/pdffiles.service";
import { PdfserviceService } from "src/app/Services/pdfservice.service";
import { DatascienceService } from "src/app/Services/datascience.service";
import { MatInput, MatDatepicker, MatSnackBar, MatSnackBarHorizontalPosition,
  MatSnackBarVerticalPosition, } from '@angular/material';
  import { PanZoomConfig, PanZoomAPI, PanZoomModel, PanZoomConfigOptions } from 'ngx-panzoom';
  import { Subscription } from 'rxjs';
  import { NgxSpinnerService } from "ngx-spinner";
  export interface imgVal{
    id : number,
    image: string
  }
@Component({
  selector: 'app-modelling',
  templateUrl: './modelling.component.html',
  styleUrls: ['./modelling.component.scss']
})
export class ModellingComponent implements OnInit {  
  modalStatusMsg: string = "";
  modelListFe: any [] = [];
  modelId: string = "";
  size: string = "";
  modelName: string = "";
  useCase: number;
  datasetNameList: string[];
  datasetNames: string = "";
  isSize: boolean = false;
  isModelName: boolean = false;
  isPretrained:boolean = false;
  isSelectModal: boolean = false;
  isFeatureModel : boolean = false;
  selectedModal: string = "";
  modelList: any[] = [];
  lrNewTrain: any = {};
  isLrNewTrainMatrix: boolean = true;
  lrOutPut: string = "";
  outTypes: any[] = [
    "Accuracy Score", "Confusion Matrix", "F1 Score", "Auc Roc Curve", "Log Loss",
    "Jaccard Score", "Recall Score", "Precision Score"
  ];
  isMessage : boolean = false;
  featureExtractionModel: any = {};
  isFeature: boolean = false;
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  private apiSubscription: Subscription;
  private apiSubscriptionAuc: Subscription;
  private panZoomAPI: PanZoomAPI;
  private panZoomAPIAuc: PanZoomAPI;
  private panZoomConfigOptions: PanZoomConfigOptions = {
    zoomLevels: 8,
    scalePerZoomLevel: 1.2,
    zoomStepDuration: 0.2,
    freeMouseWheelFactor: 0,
    zoomToFitZoomLevelFactor: 0.9,
    dragMouseButton: 'left',
    zoomOnDoubleClick: false,
    panOnClickDrag: true,
    freeMouseWheel: false
  };
  zoomPagination: boolean = false;
  panZoomConfig: PanZoomConfig = new PanZoomConfig(this.panZoomConfigOptions);
  panZoomConfigAuc: PanZoomConfig = new PanZoomConfig(this.panZoomConfigOptions);

  selectedImageIndex: any = -1;
  showFlag: any = false;
  imageObject: Array<imgVal> = [];

  constructor(
    private Pdfservice: PdfserviceService,
    private PdffilesService: PdffilesService,
    private router: Router,
    private datascienceService: DatascienceService,
    private activatedRoute: ActivatedRoute,
    private cdRef:ChangeDetectorRef,
    private _snackBar: MatSnackBar,
    private spinner: NgxSpinnerService
  ) {
    this.useCase = this.activatedRoute.snapshot.params["id"]
    this.datasetNameList =JSON.parse(this.activatedRoute.snapshot.params["datasets"]);
    this.datasetNames = this.datasetNameList.join(",");
    this.isFeature = false;
    this.apiSubscription = this.panZoomConfig.api.subscribe( (api: PanZoomAPI) => this.panZoomAPI = api );
    this.apiSubscriptionAuc = this.panZoomConfigAuc.api.subscribe( (api: PanZoomAPI) => this.panZoomAPIAuc = api );
  }

  ngOnInit() {
    this.Pdfservice.refreshModalList$.subscribe(
      (data : any )=> {
        this.isFeature = true;
        this.featureExtractionModel = data
      }
    )
  }
  /**
   * select Annotation
   */
  selectModal = (name) => {
    console.log(name);
    if(name == 'pretrained')
    {
      this.isPretrained = true;     
    }
    else if(name != 'pretrained'){
      this.isPretrained = false;
    }
  }

/**
 * validate the forms
 * @param type 
 */
  validateForm = (type) => {
    if(type == 'Pretrained')
    {
      return false
    }
    else
    {
      if(this.size != null && this.size != "" && this.isFeature == true
      && this.modelName != ""){
        this.isModelName = false;
        this.isSize = false;
        this.isFeatureModel = false;
        return true;
      }
      else
      {
        if(this.size != null && this.size != ""){
          this.isSize = false;
        }else
        {
          this.isSize = true;
        }
        if(this.isFeature)
        {
          this.isFeatureModel = false;
        }
        else
        {
          this.isFeatureModel = true;
        }
        if(this.modelName != "")
        {
          this.isModelName = false;
        }else{
          this.isModelName = true;
        }
        return false;
      }
    
    }
  }
/**
 * Get Trained
 */
  getTrained = (res) => {
    this.isLrNewTrainMatrix = true;
    let modelSelect = this.featureExtractionModel//this.modelListFe.find(model => model._id == this.modelId);
    let body = {
      usecase_id : this.useCase,
      dataset_markers:JSON.stringify(this.datasetNameList),
      test_size: this.size,
      model_name_fe: modelSelect.modelName,
      model_name_ml: this.modelName,
      model_type_fe: modelSelect.type,
      model_type_ml: "lr",
      size_fe : modelSelect.size,
      version_fe : modelSelect.version,
      version_lr : res.version
    } 
    
    this.datascienceService.getTrainedNewModelLogistic(body)
      .subscribe(
        (res) => {
          this.spinner.hide();
          if(res.status == "success")
          {
             this.lrNewTrain = res;
             this.isLrNewTrainMatrix = false;
             this.openSnackBar(res.output); 
             this.imageObject = [];
             this.imageObject.push({
               id: 1,
               image: res.confusion_matrix_img
             }); 
             this.imageObject.push({
              id: 2,
              image: res.auc_roc_curve_image
            });          
          }
        },
        (err) => {
          this.spinner.hide();
          console.log(err);
        }
      )
      this.isLrNewTrainMatrix = false;
  }
  /**
   * Save Model
   * @param body 
   */

  saveModal = (type) => {
    if(this.validateForm(type)){  
      this.isMessage = false; 
      this.spinner.show();
      let body = {
        useCaseId : this.useCase,
        datasetNames : this.datasetNameList,
        size : this.size,
        modelName : this.modelName,
        type: "lr"
      }
      let isNew = type == 'Pretrained'? false: true;
      this.datascienceService.saveModel(body,isNew)
      .subscribe(
        (res) => {
          if(res.statusCode == 200)
          {
            this.getTrained(res); 
          }
          else if(res.statusCode == 299){
            this.isMessage = true;
            this.spinner.hide();
          }
        },
        (error) => {
          console.log(error);
        }
      )
    }
  }

  /**
   * 
   */
  changeOutput = (event: Event) => {
    console.log(this.lrOutPut);
  }

  /**
   * Get Pretrained
   */
  getPretrained = () => {
    let body = {
      usecase_id : this.useCase,
      dataset_markers:JSON.stringify(this.datasetNameList),
      selected_model: this.selectedModal
    }
    
    if(body.selected_model != "")
    {
      this.isSelectModal = true;
    }
    else{
      this.isSelectModal = false;
    }
  }

   /**
   * Model List for trained 
   */
  getModelList = () => {    
    this.datascienceService.getModalList(this.useCase, this.datasetNameList, "lr")
    .subscribe(
      (res) => {
        if(res.statusCode === 200)
        {
          this.modelList = res.modelList;
        }
      }, 
      (error) => {
        console.log(error);
      }
    )
  }

/**
   * @event - openSnackBar
   * @param data 
   */
  openSnackBar(data) {
    this._snackBar.open(data,'', {
      duration: 2 * 1000,
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition
    });
  }
  onKeypress(event: any) {
    const keyChar = event.key;
    let allowCharacter: boolean;
    if (keyChar === "-" && event.target.selectionStart !== 0) {
      allowCharacter = false;
    }else if(keyChar === "-" )
    {
      return false;
    }else if(keyChar === "0" && event.target.value.trim() === "")
    {
      return false;
    }
    else if (
      keyChar === "Tab" ||
      keyChar === "Enter" ||
      keyChar === "Backspace" ||
      keyChar === "ArrowLeft" ||
      keyChar === "ArrowRight" ||
      keyChar === "Delete") {
      allowCharacter = true;
    }
    else {
      allowCharacter = (keyChar >= '0' && keyChar <= '9');
    }
  
    if (!allowCharacter) {
      event.preventDefault();
    }
  }


  zoomIn = () => {   
    let word = this.lrOutPut.trim();
    if(word == 'Confusion Matrix')
    {
      this.panZoomAPI.zoomIn();
    }
    else if(word == 'Auc Roc Curve')
    {
      this.panZoomAPIAuc.zoomIn();
    }
    
    
  }
  zoomOut = () => {
    let word = this.lrOutPut.trim();
    if(word == 'Confusion Matrix')
    {
      this.panZoomAPI.zoomOut();
    }
    else if(word == 'Auc Roc Curve')
    {
      this.panZoomAPIAuc.zoomOut();
    }
  }

  showLightbox() {
    let id = this.lrOutPut == 'Confusion Matrix'? 1 : 2;
    let index = this.imageObject.findIndex(x => x.id == id);
    this.selectedImageIndex = index;
    this.showFlag = true;
  }

  closeEventHandler() {
    this.showFlag = false;
    this.selectedImageIndex = -1;
  }
}
