import { Component, OnInit, OnDestroy,SimpleChanges, OnChanges, ViewChild,AfterViewInit,ChangeDetectionStrategy,ChangeDetectorRef } from "@angular/core";
import { Router, ActivatedRoute, Params } from "@angular/router";
import {MatTableDataSource} from '@angular/material/table';
import {MatPaginator} from '@angular/material/paginator';
import {SelectionModel} from '@angular/cdk/collections';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { PdfserviceService } from "src/app/Services/pdfservice.service";
import { DatascienceService } from "src/app/Services/datascience.service";
import {TooltipPosition} from '@angular/material/tooltip';
import { MatInput, MatDatepicker, MatSnackBar, MatSnackBarHorizontalPosition,
  MatSnackBarVerticalPosition, } from '@angular/material';
  import { PanZoomConfig, PanZoomAPI, PanZoomModel, PanZoomConfigOptions } from 'ngx-panzoom';
  import { Subscription } from 'rxjs';
  import * as SvgPanZoom from 'svg-pan-zoom';
  import { NgxSpinnerService } from "ngx-spinner";

  export interface Annotation {
  id : number;
  documentId : string,
  documentName: string;
  segmentText: string;
  segmentId : number;
  datasetName: number;
  pageNo: string;
  labelId: number;
  labelName: string,
  categoryShortName: string,
  categoryName : string,
  updateBy: string, 
  updatedOn: number,
  updateDate: Date,
  ourId: number
  }
  export interface imgVal{
    id : number,
    image: string
  }
let TABLE_DATA: Annotation[] = [];
@Component({
  selector: 'app-eda-processing',
  templateUrl: './eda-processing.component.html',
  styleUrls: ['./eda-processing.component.scss']
})
export class EdaProcessingComponent implements OnInit, AfterViewInit, OnChanges {  
	uniqueCategoryVal: string = '';
  entityData: SafeHtml;
  depandencyParse: SafeHtml;
  loadData: SafeHtml;
  annotation: any = {};
  annotationList:Annotation[] = [];
  categoryList: any[] = [];
  annotationData: Annotation[] = [];
  useCase: string ;
  datasetNameList :string[];
  category: any = {};
  categoryColumnName: string = "";  
  nGrams: string = '';
  tsneAnalysis : string = "";
  isNext: boolean = true;
  isPrev: boolean = true;
  isEntities: boolean = true;
  annotationOurId : number = 0;
  uniqueCategorySrc : string = "" ;
  datasetNames : string;
  analyzeTextValue: string = "";
  analyzeTextDependencyParse: string = "";
  worldCloud : string = "";
  istsneNo : boolean = false;
  isCustomPreprocessed : boolean = false;
  tsneNoofGrams: string ;
  stopWords : string;
  emphasisWords: string;
  customPreProcessing: string = "";
  noOfGrams: string = "";
  filterResultsNo: string = "";
  categoryName: string = "";
  isSelectedCategory: boolean = false;
  isNGramsValidate: any =
  {
    isNoOfgrams: false,
    isSelectedCategory: false,
    isFilterResultNo: false
  }
  dataSource = new MatTableDataSource<Annotation>(TABLE_DATA);
  selection = new SelectionModel<Annotation>(true, []);
  positionOptions: TooltipPosition[] = ['below', 'above', 'left', 'right'];

  selectedImageIndex: any = -1;
  showFlag: any = false;
  imageObject: Array<imgVal> = [];

  @ViewChild(MatPaginator, {static: false}) paginator: MatPaginator;
  @ViewChild(MatTableDataSource, {static: false}) table: MatTableDataSource<any>;
  private panZoomConfigOptions: PanZoomConfigOptions = {
    zoomLevels: 8,
    scalePerZoomLevel: 1.2,
    zoomStepDuration: 0.2,
    freeMouseWheelFactor: 0,
    zoomToFitZoomLevelFactor: 0.9,
    dragMouseButton: 'left',
    zoomOnDoubleClick: false,
    panOnClickDrag: true,
    freeMouseWheel: false
  };
  zoomPagination: boolean = false;

  panZoomConfig: PanZoomConfig = new PanZoomConfig(this.panZoomConfigOptions);
  panZoomConfigDependenceParse: PanZoomConfig = new PanZoomConfig(this.panZoomConfigOptions);
  panZoomConfigWordCloud: PanZoomConfig = new PanZoomConfig(this.panZoomConfigOptions);
  panZoomConfigNGrams: PanZoomConfig = new PanZoomConfig(this.panZoomConfigOptions);
  panZoomConfigTsne: PanZoomConfig = new PanZoomConfig(this.panZoomConfigOptions);

  private panZoomAPI: PanZoomAPI;
  private panZoomAPIDependenceParse: PanZoomAPI;
  private panZoomAPIWordCloud: PanZoomAPI;
  private panZoomAPINGrams: PanZoomAPI;
  private panZoomAPITsne: PanZoomAPI;

  private apiSubscription: Subscription;
  private apiSubscriptionDependenceParse: Subscription;
  private apiSubscriptionWordCloud: Subscription;
  private apiSubscriptionNGrams: Subscription;
  private apiSubscriptionTsneGrams: Subscription;

  public displayedColumns: string[] = [
    "Segment Text",   
    "Category Name",
    "Annotated by",
    "Created On"
  ];
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  constructor(
    private PdfserviceService: PdfserviceService,
    private dataScienceService: DatascienceService,
    private changeDetectorRef: ChangeDetectorRef,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private _sanitizer: DomSanitizer,
    private _snackBar: MatSnackBar,
    private spinner: NgxSpinnerService
  ) { 
    this.useCase = this.activatedRoute.snapshot.params["id"]
    this.datasetNameList =JSON.parse(this.activatedRoute.snapshot.params["datasets"]);
    this.datasetNames = this.datasetNameList.join(",");

    this.apiSubscription = this.panZoomConfig.api.subscribe( (api: PanZoomAPI) => this.panZoomAPI = api );
    this.apiSubscriptionWordCloud = this.panZoomConfigWordCloud.api.subscribe( (api: PanZoomAPI) => this.panZoomAPIWordCloud = api );
    this.apiSubscriptionNGrams = this.panZoomConfigNGrams.api.subscribe( (api: PanZoomAPI) => this.panZoomAPINGrams = api);
    this.apiSubscriptionTsneGrams = this.panZoomConfigTsne.api.subscribe( (api: PanZoomAPI) => this.panZoomAPITsne = api);
    this.apiSubscriptionDependenceParse = this.panZoomConfigDependenceParse.api.subscribe( (api: PanZoomAPI) => this.panZoomAPIDependenceParse = api)
  }

  ngOnInit() {
   this.getAnnotationList();
   this.getCategoryList();    
  // this.getUniqueCategoriesDataCount();
  }
  options = {
    zoomEnabled: true
  }
  ngAfterViewInit() {    
    this.changeDetectorRef.detectChanges();
  }
  ngOnChanges(changes: SimpleChanges){
   
  }
/**
 * 
 * @param event 
 */
  selectTab = (event) => {
    if(event.tab.textLabel == 'Unique Categories Data Count')
    {
      if(this.uniqueCategorySrc == "") {
        this.getUniqueCategoriesDataCount();
      }      
    }
    else if(event.tab.textLabel == 'Analyze Text')
    {
     if(this.entityData == undefined) {
      this.getAnalyzeTextValue();
     }
    }
    // else if(event.tab.textLabel == 'Word Cloud')
    // {
    //   this.getWordCloud();
    // }
  }

  /**
   * @trigger - next, prev, change page size
   * @param event 
   */
  onPaginateChange(event){
    this.getAnnotation(event.pageIndex);
  }

  /**
   * Get Categories list from
   */
  getCategoryList(){
    this.dataScienceService.getCategory().subscribe((res: any) =>{
      this.categoryList = res.map(s => {
        return{ ...s, count : 0}
      });
      // this.category = this.categoryList.length > 0? this.categoryList[0] : {};
      this.getAnnotation();
     // this.getWordCloud();
    },(err)=>{})
  }

  /**
   * Get Annonation data 
   * @param i 
   */
  getAnnotation(i = 0){  
    var label, labelName;
    this.paginator.pageIndex = i;   
    let body = {    
      totalNo : this.paginator.pageSize,
      startNo: this.paginator.pageIndex *this.paginator.pageSize,
      datasetNames :this.datasetNameList,
      useCase: this.useCase
    }
    this.spinner.show();
    this.dataScienceService.getAnnotations(body)
    .subscribe(
      (res) => {
        this.spinner.hide();
        if(res.statusCode == 200){
          this.paginator.length = res.total;
          this.annotationData = res.listAnnotations.map(obj => {
            label = this.categoryList.find(o => o.id == obj.labelId);
            labelName = label? label.name : "Others";
            return {...obj, updateDate: new Date(obj.updatedOn), categoryName: labelName}
          });
                    
          TABLE_DATA = this.annotationData;
          this.dataSource = new MatTableDataSource(TABLE_DATA);

        //   this.categoryList = this.categoryList.map(o => {
        //    var count = res.labels.find(x => x.labelId == o.id)
        //     return {...o, 
        //         count:count? count.count: 0,  toolTip : count? this.makeToolTipString(count.list,o): o.name }
        //         }
        //     );
          
         }
      },(err)=> {}
    )
  }
  makeToolTipString(list, obj){
    var val = obj.name;
    for(var i = 0; i < list.length; i++)
    { 
      val = val + "\n"+ list[i].datasetName + " " + list[i].count
    }
    return val;
  }
  /**
   * Next button form Analyze text
   */
  nextAnalyzeText = () => {
    this.isPrev = false;
    this.annotationOurId = this.annotationOurId + 1;
    this.annotation = this.annotationList.find(b => b.ourId === this.annotationOurId);
    if(this.annotationList.length === this.annotationOurId)
    {
      this.isNext = true;
    }
    this.getAnalyzeTextValue();
  }
  /**
   * Previous button form Analyze text
   * Next button form Analyze text
   */
  prevAnalyzeText = () => {
    this.isNext = false;
    this.annotationOurId = this.annotationOurId - 1;
    this.annotation = this.annotationList.find(b => b.ourId === this.annotationOurId);
    if(this.annotationOurId == 1)
    {
      this.isPrev = true;
    }
    this.getAnalyzeTextValue();
  }

  getAnalyzeTextValue = () => {
    let body = {
      usecase_id: this.useCase,
      dataset_markers: JSON.stringify(this.datasetNameList),
      segment_text : this.annotation.segmentText
    };
    this.spinner.show();
    this.dataScienceService.getAnalyzeText(body).subscribe(
      (res) => {
        if(res.status == "success")
        {
          this.analyzeTextValue = res.output;
          if(this.isEntities)
          {
            this.entityData = this.analyzeTextValue;            
          }
        }
      },
      (error) => {
        this.spinner.hide();
        console.log(error);
      }
    );    
    
    this.dataScienceService.getAnalyzeTextDepedencyParse(body).subscribe(
      (res) => {
        this.spinner.hide();
         if(res.status == "success")
        {
          this.analyzeTextDependencyParse = res.output;
          this.imageObject = this.imageObject.filter(x => x.id != 10);
          this.imageObject.push({ id : 10, image : res.output});
          if(!this.isEntities)
          {
            this.entityData = this.analyzeTextDependencyParse;            
          }          
        }
      },
      (error) => {
        this.spinner.hide();
        console.log(error);
      }
    );
      
      if(this.isEntities)
      {
        this.entityData = this.analyzeTextValue;
        // this.entityData = this._sanitizer.bypassSecurityTrustHtml(this.analyzeTextValue);     
      }
      else
      {
        this.entityData = this.analyzeTextDependencyParse;
        // this.entityData = this._sanitizer.bypassSecurityTrustHtml(this.analyzeTextDependencyParse);       
      }
  }

  /**
   * Get annotation list
   */
  getAnnotationList = () => {
    let c = 0;
    this.annotationList =  [];
    let body = {    
      totalNo : 0,
      startNo: 0,
      datasetNames :this.datasetNameList,
      useCase: this.useCase
    }
    this.spinner.show();
    this.dataScienceService.getAnnotations(body).subscribe(
      (res: any) => {
        if(res.statusCode === 200) {
          this.annotationList = res.listAnnotations.map(
            obj => {
              c++;
              return {...obj,ourId : c, id: c}
            }
          );
          if(this.annotationList.length > 0){
            this.isNext = false;
          }
          this.annotation = this.annotationList.length > 0? this.annotationList[0] : {};
          this.annotationOurId = this.annotation.ourId;          
        }
        this.spinner.hide();
      },
      (err)=> {
        this.spinner.hide();
        console.log(err);
      }
    )
    
  
    
    
  }
  /**
   * select Annotation
   */
  selectAnnotation = (name) => {
    if(name == 'entities')
    {
      this.isEntities = true;
      this.entityData = this.analyzeTextValue
      //this.entityData = this._sanitizer.bypassSecurityTrustHtml();
    }
    else{
      this.isEntities = false;
      this.entityData = this.analyzeTextDependencyParse;
      //this.entityData =this._sanitizer.bypassSecurityTrustHtml(this.analyzeTextDependencyParse);
    }
  }
  /**
   * get word cloud
   */
  
  getWordCloud = () => { 
    let body = 
    {
      "usecase_id": this.useCase.toString(),  
      "dataset_markers": JSON.stringify( this.datasetNameList),  
      "selected_category":this.category.name 
    }
    if(body.selected_category != "" && body.selected_category != undefined)
    {
      this.spinner.show();
      this.isSelectedCategory = false;
      this.imageObject = this.imageObject.filter(x => x.id != 2)
      this.dataScienceService.getWord(body).subscribe(
        (res) => {
          if(res.status == "success")
          {
            this.worldCloud = res.output;
            this.imageObject.push(
              {
                id : 2, 
                image :res.output
              }
            )
          }
          this.spinner.hide();
        },
        (err) => {
          this.spinner.hide();
          console.log(err);
        }
      )
    }
    else{
      this.isSelectedCategory = true;
    }
    
  }


  /**
   * Get Unique categories data count 
   */
  getUniqueCategoriesDataCount(){
    this.imageObject = [];
    let body = {
      usecase_id: this.useCase,
      dataset_markers: JSON.stringify( this.datasetNameList)
    }
    this.spinner.show();
    this.dataScienceService.getUniqueCategoriesDataCount(body).subscribe(
      res => {
        this.spinner.hide();
        if(res.status == "success")
        {
          this.uniqueCategorySrc = res.output;
          this.imageObject.filter( x=> x.id != 1);
          this.imageObject.push({
            id : 1,
            image: res.output
          })
        }
      },
      err => {
        this.spinner.hide();
        console.log(err);
      }
    )    
  }
 


  /**
    * get N grams 
    */
   
  
  getNGrams =() => {
    let body = {
      usecase_id : this.useCase,
      dataset_markers: JSON.stringify(this.datasetNameList),
      no_of_grams: this.noOfGrams,
      filter_results_no: this.filterResultsNo,
      selected_Category: this.categoryName
    }
    if(body.no_of_grams != "" && body.no_of_grams != null && body.filter_results_no != "" && body.filter_results_no != null && body.selected_Category != ""){
      this.isNGramsValidate.isNoOfgrams = false;
      this.isNGramsValidate.isFilterResultNo = false;
      this.isNGramsValidate.isSelectedCategory = false;
      this.spinner.show();
      this.dataScienceService.getNGrams(body)
      .subscribe(
        (res) => {
          this.spinner.hide();
          if(res.status === "success")
          {
            this.nGrams = res.output;
            this.imageObject = this.imageObject.filter( x=> x.id != 3);
            this.imageObject.push({
              id : 3,
              image: res.output
            })
          }
        },
        (error) => {
          this.spinner.hide();
          console.log(error);
        }
      );
    }
    else
    {
      if(body.no_of_grams == "" || body.no_of_grams == null)
      {
        this.isNGramsValidate.isNoOfgrams = true;
      }else{
        this.isNGramsValidate.isNoOfgrams = false;
      }
      if(body.filter_results_no == "" || body.filter_results_no == null)
      {
        this.isNGramsValidate.isFilterResultNo = true;
      }else{
        this.isNGramsValidate.isFilterResultNo = false;
      }
      if(body.selected_Category == "" || body.selected_Category == null)
      {
        this.isNGramsValidate.isSelectedCategory = true;
      }else{
        this.isNGramsValidate.isSelectedCategory = false;
      }
    }    
  }

  /**
   * Get TSNE Analysis
   */
  getTsneAnalysis = () => {
    let body = {
      usecase_id : this.useCase,
      dataset_markers : JSON.stringify( this.datasetNameList),
      no_of_grams : this.tsneNoofGrams
    }
    if(body.no_of_grams != "" && body.no_of_grams != undefined && body.no_of_grams != null){
      this.spinner.show();
      this.istsneNo = false;
      this.dataScienceService.getTsneAnalysis(body).subscribe(
        (res) => {
          this.spinner.hide();
          if(res.status == "success")
          {
            this.tsneAnalysis = res.output;
            //this.tsneNoofGrams = "";  
            this.imageObject = this.imageObject.filter( x=> x.id != 4);
            this.imageObject.push({
              id : 4,
              image: res.output
            })         
          }
        }
        ,(error) => {
          this.spinner.hide();
          console.log(error);
        }
      )
    }
    else{
      this.istsneNo = true;
    }    
    
  }

  /**
    * Get Custome Pre processing
  */
  getCustomPreprocessing = () => {
    let body = {
      usecase_id: this.useCase,
      dataset_markers: JSON.stringify( this.datasetNameList),
      stopwords: this.stopWords,
      emphasized_words: this.emphasisWords
    }
    if((body.stopwords && body.stopwords.length > 0) || (body.emphasized_words && body.emphasized_words.length >0)){
      this.isCustomPreprocessed = false;
      this.spinner.show();
      this.dataScienceService.getCustomPreprocessing(body)
    .subscribe(
      (res) => {
        this.spinner.hide();
        if(res.status === "success")
        {
          this.customPreProcessing = res.output;
          this.openSnackBar(res.output);

        }
      },
      (error) => {
        this.spinner.hide();
        console.log(error);
      }
    )
    }
    else
    {
      this.isCustomPreprocessed = true;
    }
  }
 /**
   * @event - openSnackBar
   * @param data 
   */
  openSnackBar(data) {
    this._snackBar.open(data,'', {
      duration: 2 * 1000,
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition
    });
  }

  zoomIn = (word) => {
    console.log(word);
    if(word == 'uniqueCategoriesCount')
    {
      this.panZoomAPI.zoomIn();
    }
    else if(word == 'wordCloud')
    {
      this.panZoomAPIWordCloud.zoomIn();
    }
    else if(word == 'N-grams')
    {
      this.panZoomAPINGrams.zoomIn();
    }
    else if(word == 'tsne-grams'){
      this.panZoomAPITsne.zoomIn();
    }
    else if(word == 'DependencyParse'){
      this.panZoomAPIDependenceParse.zoomIn();
    }
    
  }
  zoomOut = (word) => {
    if(word == 'uniqueCategoriesCount')
    {
      this.panZoomAPI.zoomOut();
    }
    else if(word == 'wordCloud')
    {
      this.panZoomAPIWordCloud.zoomOut();
    }
    else if(word == 'N-grams')
    {
      this.panZoomAPINGrams.zoomOut();
    }
    else if(word == 'tsne-grams'){
      this.panZoomAPITsne.zoomOut();
    }
    else if(word == 'DependencyParse'){
      this.panZoomAPIDependenceParse.zoomOut();
    }
  }

  showLightbox(id) {
    let index = this.imageObject.findIndex(x => x.id == id);
    this.selectedImageIndex = index;
    this.showFlag = true;
  }

  closeEventHandler() {
    this.showFlag = false;
    this.selectedImageIndex = -1;
  }

  refreshSvg()  {
    // console.log(SvgPanZoom);
    // console.log(document.getElementsByClassName('annotation-second-text'));
    // let svgPanZoom: SvgPanZoom.Instance = SvgPanZoom('.annotation-second-text', this.options);
    // console.log(svgPanZoom);
  }

  onKeypress(event: any) {
    const keyChar = event.key;
    let allowCharacter: boolean;
    if (keyChar === "-" && event.target.selectionStart !== 0) {
      allowCharacter = false;
    }else if(keyChar === "-" )
    {
      return false;
    }else if(keyChar === "0" && event.target.value.trim() === "")
    {
      return false;
    }
    else if (
      keyChar === "Tab" ||
      keyChar === "Enter" ||
      keyChar === "Backspace" ||
      keyChar === "ArrowLeft" ||
      keyChar === "ArrowRight" ||
      keyChar === "Delete") {
      allowCharacter = true;
    }
    else {
      allowCharacter = (keyChar >= '0' && keyChar <= '9');
    }
  
    if (!allowCharacter) {
      event.preventDefault();
    }
  }

}
