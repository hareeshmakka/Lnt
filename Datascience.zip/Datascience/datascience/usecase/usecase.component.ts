import { ChangeDetectorRef, Component, OnInit, ViewChild } from "@angular/core";
import { MatPaginator, MatTableDataSource } from "@angular/material";
import { Router } from "@angular/router";
import { Observable } from "rxjs";
import { PdfserviceService } from "src/app/Services/pdfservice.service";
import { DatascienceService } from "src/app/Services/datascience.service";

export interface UseCase {
  useCaseId: number,
  useCaseName: string,
  useCaseDescription: string, 
  createBy : string,
  createdOn: Date,
  userId: string
}
@Component({
  selector: 'app-usecase',
  templateUrl: './usecase.component.html',
  styleUrls: ['./usecase.component.scss']
})
export class UsecaseComponent implements OnInit {
  hide: boolean = false;
  searchValue: any;
  pageEvent:any;
  startNo: number = 0;
  endNo: number = 10;
  useCase : UseCase[] = [];
  useCases: UseCase[] = [];

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  obs: Observable<any>;
  dataSource: MatTableDataSource<UseCase> = new MatTableDataSource<UseCase>(
    this.useCase
  );
  constructor(
    private router: Router,
    private PdfserviceService: PdfserviceService,
    private dataScienceService: DatascienceService,
    private changeDetectorRef: ChangeDetectorRef
  ) { 
    
  }

  ngOnInit() {
    this.changeDetectorRef.detectChanges();
    this.dataSource.paginator = this.paginator;
    this.obs = this.dataSource.connect();
    this.PdfserviceService.annotation("useCases");
    this.PdfserviceService.searchValue$.subscribe((val) => {
      this.search(val);
    });
    this.getUseCasesList()
  }
/**
 * get use case list
 */
  getUseCasesList(){
    let id = localStorage.getItem("useCaseId");
    this.dataScienceService.getUseCases()
    .subscribe((res: any)=> {
      if(res.statusCode == 200){
        this.useCase = res.useCaseList;
        this.useCases = [...res.useCaseList]
        this.dataSource.data = this.useCase;
      }else{
        this.useCase = []
      }
    }, err => {

    })
  }
  ngOnDestroy() {
    if (this.dataSource) {
      this.dataSource.disconnect();
    }
  }
  /**
   * Navigate the dateset screen
   * @param useCaseId 
   */
  projectnav(useCaseId, useCaseName) {  
    localStorage.setItem("useCaseId", useCaseId);
    localStorage.setItem("useCaseName", useCaseName); 
    this.router.navigate(["/datascience/dataset", { id: useCaseId }]);
  }
/**
 * Not used
 * @param value 
 */
  search(value){
    value = value.toLowerCase();
    if(value){
      this.useCase = this.useCases.filter(o => {
        return o.useCaseName.toLowerCase().startsWith(value) || o.useCaseDescription.toLowerCase().startsWith(value)
      })
      this.dataSource.data = this.useCase;
    }else{
      this.useCase = this.useCases;
      this.dataSource.data = this.useCase;
    }    
  }
  /**
   * Page changed time it will be trigger
   * @param event 
   */
  onPaginateChange(event){
     this.startNo = event.pageIndex * event.pageSize;
     this.endNo = event.pageIndex * event.pageSize +  event.pageSize;
  }
}
