import { Component, OnInit, OnDestroy , ViewChild,AfterViewInit,ChangeDetectionStrategy,ChangeDetectorRef } from "@angular/core";
import { Router, ActivatedRoute, Params } from "@angular/router";
import { PdfserviceService } from "src/app/Services/pdfservice.service";
import { DatascienceService } from "src/app/Services/datascience.service";
import {TooltipPosition} from '@angular/material/tooltip';
import { _MatTabBodyBase } from "@angular/material";
import { MatInput, MatDatepicker, MatSnackBar, MatSnackBarHorizontalPosition,
  MatSnackBarVerticalPosition, } from '@angular/material';
  import { NgxSpinnerService } from "ngx-spinner";
@Component({
  selector: 'app-feature-extraction',
  templateUrl: './feature-extraction.component.html',
  styleUrls: ['./feature-extraction.component.scss']
})
export class FeatureExtractionComponent implements OnInit {
  isPretrained:boolean = false;
  useCase: string;
  datasetNameList: string[];
  modelList:any[] = [];
  modelId: string = "";
  datasetNames: string;
  minCount: string = "";
  sizeCount: string = "";
  noOfWorkers: string = "";
  modelName: string = "";
  pretrainedOutput: string = "";
  modalStatusMsg: string = "";
  trainedOutput: string = "";
  isSelectedModal: boolean = false;
  isMessage: boolean = false;
  isValid : any = {
    isMinCount: false,
    isSize : false,
    isNoOfWorkers : false,
    isModelName: false
  }
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  constructor(
    private PdfserviceService: PdfserviceService,
    private dataScienceService: DatascienceService,
    private changeDetectorRef: ChangeDetectorRef,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private _snackBar: MatSnackBar,
    private spinner: NgxSpinnerService
  ) {
    this.useCase = this.activatedRoute.snapshot.params["id"]
    this.datasetNameList =JSON.parse(this.activatedRoute.snapshot.params["datasets"]);
    this.datasetNames = this.datasetNameList.join(",");
   }

  ngOnInit() {
    this.getModelList();
  }

  /**
   * select Annotation
   */
  selectModal = (name) => {
    if(name == 'pretrained')
    {
      this.isPretrained = true;     
    }
    else if(name != 'pretrained'){
      this.isPretrained = false;
    }
  }


  /**
   * Model List for trained 
   */
  getModelList = () => {    
    this.dataScienceService.getModalList(this.useCase, this.datasetNameList, "word2vec")
    .subscribe(
      (res) => {
        if(res.statusCode === 200)
        {
          this.modelList = res.modelList;
          
        }
      }, 
      (error) => {
        this.spinner.hide();
        console.log(error);
      }
    )
  }


  /**
   * Generate Pretrained and Model
   */
  genarateTrained = (data, model) => {
    
    let body = {
      usecase_id : this.useCase,
      dataset_markers: JSON.stringify(this.datasetNameList),
      min_count: this.minCount.toString(),
      model_name: this.modelName,
      size : this.sizeCount.toString(),
      workers: this.noOfWorkers.toString(),
      version: data.version
    }
    if(body.min_count != "" && body.min_count != null
     && body.model_name != "" && body.model_name != null 
     && body.size != "" && body.size != null 
     && body.workers != "" && body.workers != null)
    {
      this.isValid.isMinCount = false;
      this.isValid.isModelName = false;
      this.isValid.isSize = false;
      this.isValid.isNoOfWorkers = false;
      this.PdfserviceService.refreshModalListM(model);
      this.dataScienceService.getTrainedNewModelW2V(body)
      .subscribe(
        (res) => {
          if(res.status == "success")
          {
            this.pretrainedOutput = res.output; 
            this.openSnackBar(res.output); 
            this.PdfserviceService.refreshModalListM(model);          
          }
          this.spinner.hide();
        },
        (error) => {
          this.spinner.hide();
          console.log(error);
        }
      )
    }
    else{
      if(body.min_count == ""  || body.min_count == null)
      {
        this.isValid.isMinCount = true;
      }
      else
      {
        this.isValid.isMinCount = false;
      }
      if(body.model_name == "")
      {
        this.isValid.isModelName = true;
      }
      else
      {
        this.isValid.isModelName = false;
      }
      if(body.size == "" || body.size == null)
      {
        this.isValid.isSize = true;
      }
      else
      {
        this.isValid.isSize = false;
      }
      if(body.workers == "" || body.workers == null)
      {
        this.isValid.isNoOfWorkers = true;
      }
      else
      {
        this.isValid.isNoOfWorkers = false;
      }
    }
  }
  /**
   * Save Model
   * @param body 
   */

  saveModal = (type) => {    
    if(this.validateForm(type)){
      this.spinner.show();
      this.isMessage = false;
    let modelSelect = this.modelList.find(model => model._id == this.modelId);
    let body:any = {
      useCaseId : this.useCase,
      datasetNames : this.datasetNameList,
      size : (type == 'Pretrained') ? modelSelect.size : this.sizeCount,
      modelName :(type == 'Pretrained') ? modelSelect.modelName : this.modelName,
      type: "word2vec"
    }
    let isNew = type == 'Pretrained'? false: true;
    this.dataScienceService.saveModel(body,isNew)
    .subscribe(
      (res) => {
        if(res.statusCode == 200)
        {
          this.modalStatusMsg = res.statusMessage;
          this.getModelList();
          
          if(type == 'trained')
          {
            body.version = res.version;
            this.genarateTrained(res, body);
          }else{
            body.version = res.version;
            this.getPreTrained(res, body);
          }
        }
        else if(res.statusCode == 299){
          this.spinner.hide();
          this.isMessage = true;
        }
      },
      (error) => {
        this.spinner.hide();
        console.log(error);
      }
    )
    }
  }

  validateForm = (type) => {
    if(type == 'Pretrained')
    {
      if(this.modelId != "")
      {
        this.isSelectedModal = false;
        return true;
      }
      else{
        this.isSelectedModal = true;
        return false;
      }
    }
    else
    {
      if(this.minCount != ""  && this.minCount != null && this.modelName != ""
      && this.sizeCount != "" && this.sizeCount != null && this.noOfWorkers != "" 
      && this.noOfWorkers != null && this.sizeCount != "" && this.sizeCount != null){
        this.isValid.isMinCount = false;
        this.isValid.isModelName = false;
        this.isValid.isSize = false;
        this.isValid.isNoOfWorkers = false;
        return true;
      }
      else{
        if(this.minCount == ""  || this.minCount == null)
        {
          this.isValid.isMinCount = true;
        }
        else
        {
          this.isValid.isMinCount = false;
        }
        if(this.modelName == "")
        {
          this.isValid.isModelName = true;
        }
        else
        {
          this.isValid.isModelName = false;
        }
        if(this.sizeCount == "" || this.sizeCount == null)
        {
          this.isValid.isSize = true;
        }
        else
        {
          this.isValid.isSize = false;
        }
        if(this.noOfWorkers == "" || this.noOfWorkers == null)
        {
          this.isValid.isNoOfWorkers = true;
        }
        else
        {
          this.isValid.isNoOfWorkers = false;
        }
        return false;
      }
    }
  }

  /**
   * get trained 
   */
  getPreTrained = (data, model) => {
    let modelSelect = this.modelList.find(model => model._id == this.modelId);
 
    // if(this.modelId != "")
    // {
    //   this.isSelectedModal = false;
      let body = {
        usecase_id : this.useCase, 
        dataset_markers : JSON.stringify(this.datasetNameList),
        selected_model : modelSelect.modelName,
        size : modelSelect.size,
        selected_model_version : modelSelect.version,
        new_version : data.version,
        model_type: 'word2vec'
      }
     // this.PdfserviceService.refreshModalListM(model);
      this.dataScienceService.getPreTrainedModelW2V(body)
      .subscribe(
        (res) => {
          this.spinner.hide();
          if(res.status == "success")
          {
            this.trainedOutput = res.output;  
            this.PdfserviceService.refreshModalListM(model);
          this.openSnackBar(res.output);
          }
        },
        (error) => {
          this.spinner.hide();
          console.log(error);
        }
      )
     
    // }
    // else
    // {
    //   this.isSelectedModal = true;
    // }   
  }

  onKeypress(event: any) {
    const keyChar = event.key;
    let allowCharacter: boolean;
    if (keyChar === "-" && event.target.selectionStart !== 0) {
      allowCharacter = false;
    }else if(keyChar === "-" )
    {
      return false;
    }else if(keyChar === "0" && event.target.value.trim() === "")
    {
      return false;
    }
    else if (
      keyChar === "Tab" ||
      keyChar === "Enter" ||
      keyChar === "Backspace" ||
      keyChar === "ArrowLeft" ||
      keyChar === "ArrowRight" ||
      keyChar === "Delete") {
      allowCharacter = true;
    }
    else {
      allowCharacter = (keyChar >= '0' && keyChar <= '9');
    }
  
    if (!allowCharacter) {
      event.preventDefault();
    }
  }

   /**
   * @event - openSnackBar
   * @param data 
   */
  openSnackBar(data) {
    this._snackBar.open(data,'', {
      duration: 2 * 1000,
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition
    });
  }
}
