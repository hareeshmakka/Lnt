import { Component, OnInit, OnDestroy , ViewChild,AfterViewInit,ChangeDetectionStrategy,ChangeDetectorRef } from "@angular/core";
import { Router , ActivatedRoute} from "@angular/router";
import { PdffilesService } from "src/app/Services/pdffiles.service";
import { PdfserviceService } from "src/app/Services/pdfservice.service";
import { DatascienceService } from "src/app/Services/datascience.service";
@Component({
  selector: 'app-modelling',
  templateUrl: './modelling.component.html',
  styleUrls: ['./modelling.component.scss']
})
export class ModellingComponent implements OnInit {  
  modalStatusMsg: string = "";
  modelListFe: any [] = [];
  modelId: string = "";
  size: string = "";
  modelName: string = "";
  useCase: number;
  datasetNameList: string[];
  datasetNames: string = "";
  isSize: boolean = false;
  isModelName: boolean = false;
  isPretrained:boolean = false;
  isSelectModal: boolean = false;
  isFeatureModel : boolean = false;
  selectedModal: string = "";
  modelList: any[] = [];
  lrNewTrain: any = {};
  isLrNewTrainMatrix: boolean = true;
  lrOutPut: string = "";
  outTypes: any[] = [
    "Accuracy Score", "Confusion Matrix", "F1 Score"
  ];
  isMessage : boolean = false;
  featureExtractionModel: any = {};
  isFeature: boolean = false;

  constructor(
    private Pdfservice: PdfserviceService,
    private PdffilesService: PdffilesService,
    private router: Router,
    private datascienceService: DatascienceService,
    private activatedRoute: ActivatedRoute,
    private cdRef:ChangeDetectorRef
  ) {
    this.useCase = this.activatedRoute.snapshot.params["id"]
    this.datasetNameList =JSON.parse(this.activatedRoute.snapshot.params["datasets"]);
    this.datasetNames = this.datasetNameList.join(",");
    this.isFeature = false;
  }

  ngOnInit() {
    this.Pdfservice.refreshModalList$.subscribe(
      (data : any )=> {
        this.isFeature = true;
        this.featureExtractionModel = data
      }
    )
  }
  /**
   * select Annotation
   */
  selectModal = (name) => {
    console.log(name);
    if(name == 'pretrained')
    {
      this.isPretrained = true;     
    }
    else if(name != 'pretrained'){
      this.isPretrained = false;
    }
  }

/**
 * validate the forms
 * @param type 
 */
  validateForm = (type) => {
    if(type == 'Pretrained')
    {
      return false
    }
    else
    {
      if(this.size != null && this.size != "" && this.isFeature == true
      && this.modelName != ""){
        this.isModelName = false;
        this.isSize = false;
        this.isFeatureModel = false;
        return true;
      }
      else
      {
        if(this.size != null && this.size != ""){
          this.isSize = false;
        }else
        {
          this.isSize = true;
        }
        if(this.isFeature)
        {
          this.isFeatureModel = false;
        }
        else
        {
          this.isFeatureModel = true;
        }
        if(this.modelName != "")
        {
          this.isModelName = false;
        }else{
          this.isModelName = true;
        }
        return false;
      }
    
    }
  }
/**
 * Get Trained
 */
  getTrained = (res) => {
    let modelSelect = this.featureExtractionModel//this.modelListFe.find(model => model._id == this.modelId);
    let body = {
      usecase_id : this.useCase,
      dataset_markers:JSON.stringify(this.datasetNameList),
      test_size: this.size,
      model_name_fe: modelSelect.modelName,
      model_name_ml: this.modelName,
      model_type_fe: modelSelect.type,
      model_type_ml: "lr",
      size_fe : modelSelect.size,
      version_fe : modelSelect.version,
      version_lr : res.version
    } 
    
    this.datascienceService.getTrainedNewModelLogistic(body)
      .subscribe(
        (res) => {
          if(res.status == "success")
          {
             this.lrNewTrain = res;           
          }
        },
        (err) => {
          console.log(err);
        }
      )
      this.isLrNewTrainMatrix = false;
  }
  /**
   * Save Model
   * @param body 
   */

  saveModal = (type) => {
    if(this.validateForm(type)){  
      this.isMessage = false; 
      let body = {
        useCaseId : this.useCase,
        datasetNames : this.datasetNameList,
        size : this.size,
        modelName : this.modelName,
        type: "lr"
      }
      let isNew = type == 'Pretrained'? false: true;
      this.datascienceService.saveModel(body,isNew)
      .subscribe(
        (res) => {
          if(res.statusCode == 200)
          {
            this.getTrained(res); 
          }
          else if(res.statusCode == 299){
            this.isMessage = true;
          }
        },
        (error) => {
          console.log(error);
        }
      )
    }
  }

  /**
   * 
   */
  changeOutput = (event: Event) => {
    console.log(this.lrOutPut);
  }

  /**
   * Get Pretrained
   */
  getPretrained = () => {
    let body = {
      usecase_id : this.useCase,
      dataset_markers:JSON.stringify(this.datasetNameList),
      selected_model: this.selectedModal
    }
    
    if(body.selected_model != "")
    {
      this.isSelectModal = true;
    }
    else{
      this.isSelectModal = false;
    }
  }

   /**
   * Model List for trained 
   */
  getModelList = () => {    
    this.datascienceService.getModalList(this.useCase, this.datasetNameList, "lr")
    .subscribe(
      (res) => {
        if(res.statusCode === 200)
        {
          this.modelList = res.modelList;
        }
      }, 
      (error) => {
        console.log(error);
      }
    )
  }


  onKeypress(event: any) {
    const keyChar = event.key;
    let allowCharacter: boolean;
    if (keyChar === "-" && event.target.selectionStart !== 0) {
      allowCharacter = false;
    }else if(keyChar === "-" )
    {
      return false;
    }else if(keyChar === "0" && event.target.value.trim() === "")
    {
      return false;
    }
    else if (
      keyChar === "Tab" ||
      keyChar === "Enter" ||
      keyChar === "Backspace" ||
      keyChar === "ArrowLeft" ||
      keyChar === "ArrowRight" ||
      keyChar === "Delete") {
      allowCharacter = true;
    }
    else {
      allowCharacter = (keyChar >= '0' && keyChar <= '9');
    }
  
    if (!allowCharacter) {
      event.preventDefault();
    }
  }
}
