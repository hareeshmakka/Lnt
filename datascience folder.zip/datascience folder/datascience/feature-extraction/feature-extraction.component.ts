import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-feature-extraction',
  templateUrl: './feature-extraction.component.html',
  styleUrls: ['./feature-extraction.component.scss']
})
export class FeatureExtractionComponent implements OnInit {
  isPretrained:boolean = true;
  annotationList:any[] = [
    {name:'Annotation text 1', id: 1, segmentText : "Data, agenda, strata are plurals taken directly from the Latin singular nouns datum, agendum and stratum respectively. So, they are plural. ‘Data are.  However, we are not ancient Romans (ancient, some of us, like me, but not quite that ancient). Having adopted a word, it is ours to raise as we wish"},
    {name:'Annotation text 2', id: 2, segmentText : "Data, agenda, strata are plurals taken directly from the Latin singular nouns datum, agendum and stratum respectively. So, they are plural. ‘Data are.  However, we are not ancient Romans (ancient, some of us, like me, but not quite that ancient). Having adopted a word, it is ours to raise as we wish"},
    {name:'Annotation text 1', id: 3, segmentText : "Data, agenda, strata are plurals taken directly from the Latin singular nouns datum, agendum and stratum respectively. So, they are plural. ‘Data are.  However, we are not ancient Romans (ancient, some of us, like me, but not quite that ancient). Having adopted a word, it is ours to raise as we wish"},
    {name:'Annotation text 2', id: 4, segmentText : "Data, agenda, strata are plurals taken directly from the Latin singular nouns datum, agendum and stratum respectively. So, they are plural. ‘Data are.  However, we are not ancient Romans (ancient, some of us, like me, but not quite that ancient). Having adopted a word, it is ours to raise as we wish"},
    {name:'Annotation text 1', id: 5, segmentText : "Data, agenda, strata are plurals taken directly from the Latin singular nouns datum, agendum and stratum respectively. So, they are plural. ‘Data are.  However, we are not ancient Romans (ancient, some of us, like me, but not quite that ancient). Having adopted a word, it is ours to raise as we wish"},
    {name:'Annotation text 2', id: 6, segmentText : "Data, agenda, strata are plurals taken directly from the Latin singular nouns datum, agendum and stratum respectively. So, they are plural. ‘Data are.  However, we are not ancient Romans (ancient, some of us, like me, but not quite that ancient). Having adopted a word, it is ours to raise as we wish"},
    {name:'Annotation text 1', id: 7, segmentText : "Data, agenda, strata are plurals taken directly from the Latin singular nouns datum, agendum and stratum respectively. So, they are plural. ‘Data are.  However, we are not ancient Romans (ancient, some of us, like me, but not quite that ancient). Having adopted a word, it is ours to raise as we wish"},
    {name:'Annotation text 2', id: 8, segmentText : "Data, agenda, strata are plurals taken directly from the Latin singular nouns datum, agendum and stratum respectively. So, they are plural. ‘Data are.  However, we are not ancient Romans (ancient, some of us, like me, but not quite that ancient). Having adopted a word, it is ours to raise as we wish"},
  ]
  constructor() { }

  ngOnInit() {
  }

  /**
   * select Annotation
   */
  selectModal = (name) => {
    if(name == 'pretrained')
    {
      this.isPretrained = true;
     
    }
    else{
      this.isPretrained = false;
    }
  }


  onKeypress(event: any) {
    const keyChar = event.key;
    let allowCharacter: boolean;
    if (keyChar === "-" && event.target.selectionStart !== 0) {
      allowCharacter = false;
    }else if(keyChar === "-" )
    {
      return false;
    }else if(keyChar === "0" && event.target.value.trim() === "")
    {
      return false;
    }
    else if (
      keyChar === "Tab" ||
      keyChar === "Enter" ||
      keyChar === "Backspace" ||
      keyChar === "ArrowLeft" ||
      keyChar === "ArrowRight" ||
      keyChar === "Delete") {
      allowCharacter = true;
    }
    else {
      allowCharacter = (keyChar >= '0' && keyChar <= '9');
    }
  
    if (!allowCharacter) {
      event.preventDefault();
    }
  }
}
