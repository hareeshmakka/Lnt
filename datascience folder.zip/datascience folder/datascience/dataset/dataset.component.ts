import { ChangeDetectorRef, Component, OnInit, ViewChild } from "@angular/core";
import { MatPaginator, MatTableDataSource } from "@angular/material";
import { Router, ActivatedRoute, Params } from "@angular/router";
import { Observable } from "rxjs";
import { PdfserviceService } from "src/app/Services/pdfservice.service";
import { DatascienceService } from "src/app/Services/datascience.service";
export interface project {
  datasetName: string,
  createdBy: string,
  createdOn: number,
  createdDate: Date,
  checked : boolean
}

@Component({
  selector: 'app-dataset',
  templateUrl: './dataset.component.html',
  styleUrls: ['./dataset.component.scss']
})
export class DatasetComponent implements OnInit {
  hide: boolean = false;
  searchValue: any;
  pageEvent:any;
  startNo: number = 0;
  endNo: number = 10;
  dataset : project[] = [];
  datasets: project[] = [];
  useCaseId : number;
  isConfirm: boolean = false;

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  obs: Observable<any>;
  dataSource: MatTableDataSource<project> = new MatTableDataSource<project>(
    this.dataset
  );

  constructor(
    private router: Router,
    private PdfserviceService: PdfserviceService,
    private dataScienceService: DatascienceService,
    private changeDetectorRef: ChangeDetectorRef,
    private activatedRoute: ActivatedRoute
  ) { }

  ngOnInit() {
    this.changeDetectorRef.detectChanges();
    this.dataSource.paginator = this.paginator;
    this.obs = this.dataSource.connect();
    this.PdfserviceService.annotation("History");
    let useCaseName = localStorage.getItem('useCaseName');
    this.PdfserviceService.setUseCaseName(useCaseName);
    this.PdfserviceService.searchValue$.subscribe((val) => {
      this.search(val);
    });   
    this.getDatasetList()
  }

  
  
  ngOnDestroy() {
    if (this.dataSource) {
      this.dataSource.disconnect();
    }
    this.PdfserviceService.setUseCaseName("");
  }
/**
 * Data set list 
 * 
 */
  getDatasetList(){
    let id = localStorage.getItem('useCaseId');
    this.dataScienceService.getDataSets(id)
    .subscribe((res: any)=> {
      if(res.statusCode == 200){
         this.dataset = res.dataSetList;
         this.datasets = [...res.dataSetList]
         this.dataSource.data = this.dataset;
      }else{
        this.dataset = []
      }
    }, err => {

    })
  }
  
  /**
   * confirm
   * @param value 
   */
  confirm() {
    let id = localStorage.getItem('useCaseId');
    let ids = this.dataset.filter(o => o.checked == true).map( d => d.datasetName);
    this.router.navigate(["/datascience/datascience", { datasets: JSON.stringify(ids), id:id }])
  }
  /**
   * Cancel - clear check boxes
   * 
   */
  cancel(){
    this.dataset = this.dataset.map(o=> {
      return {...o, checked: false};
    })
  }
/**
 * Search the Usecase name or Usecase description
 * @param value 
 */
  search(value){
    value = value.toLowerCase();
    if(value){
      this.dataset = this.datasets.filter(o => {
        return o.datasetName.toLowerCase().startsWith(value);
      })
      this.dataSource.data = this.dataset;
    }else{
      this.dataset = this.datasets;
      this.dataSource.data = this.dataset;
    }
    
  }
  /**
   * Page changed time it will be trigger
   * @param event 
   */
  onPaginateChange(event){
     this.startNo = event.pageIndex * event.pageSize;
     this.endNo = event.pageIndex * event.pageSize +  event.pageSize;
  }

  checked(){
   var check = this.dataset.filter(d => d.checked == true).length;
   if(check > 0)
      return false;
   else
      return true;   
  }
}
