import { Component, OnInit, OnDestroy , ViewChild,AfterViewInit,ChangeDetectionStrategy,ChangeDetectorRef } from "@angular/core";
import { Router , ActivatedRoute} from "@angular/router";
import { PdffilesService } from "src/app/Services/pdffiles.service";
import { PdfserviceService } from "src/app/Services/pdfservice.service";
import { DatascienceService } from "src/app/Services/datascience.service";
@Component({
  selector: 'app-modelling',
  templateUrl: './modelling.component.html',
  styleUrls: ['./modelling.component.scss']
})
export class ModellingComponent implements OnInit {
  annotation : any = {
    name: ''
  };
  size: number;
  useCase: number;
  datasetNameList: string[];
  annotationList:any[] = [
    {name:'Annotation text 1', id: 1, segmentText : "Data, agenda, strata are plurals taken directly from the Latin singular nouns datum, agendum and stratum respectively. So, they are plural. ‘Data are.  However, we are not ancient Romans (ancient, some of us, like me, but not quite that ancient). Having adopted a word, it is ours to raise as we wish"},
    {name:'Annotation text 2', id: 2, segmentText : "Data, agenda, strata are plurals taken directly from the Latin singular nouns datum, agendum and stratum respectively. So, they are plural. ‘Data are.  However, we are not ancient Romans (ancient, some of us, like me, but not quite that ancient). Having adopted a word, it is ours to raise as we wish"},
    {name:'Annotation text 1', id: 1, segmentText : "Data, agenda, strata are plurals taken directly from the Latin singular nouns datum, agendum and stratum respectively. So, they are plural. ‘Data are.  However, we are not ancient Romans (ancient, some of us, like me, but not quite that ancient). Having adopted a word, it is ours to raise as we wish"},
    {name:'Annotation text 2', id: 2, segmentText : "Data, agenda, strata are plurals taken directly from the Latin singular nouns datum, agendum and stratum respectively. So, they are plural. ‘Data are.  However, we are not ancient Romans (ancient, some of us, like me, but not quite that ancient). Having adopted a word, it is ours to raise as we wish"},
    {name:'Annotation text 1', id: 1, segmentText : "Data, agenda, strata are plurals taken directly from the Latin singular nouns datum, agendum and stratum respectively. So, they are plural. ‘Data are.  However, we are not ancient Romans (ancient, some of us, like me, but not quite that ancient). Having adopted a word, it is ours to raise as we wish"},
    {name:'Annotation text 2', id: 2, segmentText : "Data, agenda, strata are plurals taken directly from the Latin singular nouns datum, agendum and stratum respectively. So, they are plural. ‘Data are.  However, we are not ancient Romans (ancient, some of us, like me, but not quite that ancient). Having adopted a word, it is ours to raise as we wish"},
    {name:'Annotation text 1', id: 1, segmentText : "Data, agenda, strata are plurals taken directly from the Latin singular nouns datum, agendum and stratum respectively. So, they are plural. ‘Data are.  However, we are not ancient Romans (ancient, some of us, like me, but not quite that ancient). Having adopted a word, it is ours to raise as we wish"},
    {name:'Annotation text 2', id: 2, segmentText : "Data, agenda, strata are plurals taken directly from the Latin singular nouns datum, agendum and stratum respectively. So, they are plural. ‘Data are.  However, we are not ancient Romans (ancient, some of us, like me, but not quite that ancient). Having adopted a word, it is ours to raise as we wish"},
  ];
  constructor(
    private PdfserviceService: PdfserviceService,
    private PdffilesService: PdffilesService,
    private router: Router,
    private datascienceService: DatascienceService,
    private activatedRoute: ActivatedRoute,
    private cdRef:ChangeDetectorRef
  ) {
    this.useCase = this.activatedRoute.snapshot.params["id"]
    this.datasetNameList =JSON.parse(this.activatedRoute.snapshot.params["datasets"]);
    console.log(this.useCase,this.datasetNameList)
  }

  ngOnInit() {}

  onKeypress(event: any) {
    const keyChar = event.key;
    let allowCharacter: boolean;
    if (keyChar === "-" && event.target.selectionStart !== 0) {
      allowCharacter = false;
    }else if(keyChar === "-" )
    {
      return false;
    }else if(keyChar === "0" && event.target.value.trim() === "")
    {
      return false;
    }
    else if (
      keyChar === "Tab" ||
      keyChar === "Enter" ||
      keyChar === "Backspace" ||
      keyChar === "ArrowLeft" ||
      keyChar === "ArrowRight" ||
      keyChar === "Delete") {
      allowCharacter = true;
    }
    else {
      allowCharacter = (keyChar >= '0' && keyChar <= '9');
    }
  
    if (!allowCharacter) {
      event.preventDefault();
    }
  }



}
