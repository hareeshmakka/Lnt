import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from "@angular/router";
import { FlexLayoutModule } from "@angular/flex-layout";
import { Ng2SearchPipeModule } from "ng2-search-filter";
import { FormsModule } from "@angular/forms";
import {MatDialogModule} from '@angular/material/dialog';



import { UsecaseComponent } from './usecase/usecase.component';
import { ConfigComponent } from './config/config.component';
import { HistoryComponent } from './history/history.component';
import { DatascienceComponent } from './datascience/datascience.component';
import { CarouselModule } from 'ngx-owl-carousel-o';

import {  
  MatButtonModule,
  MatCardModule,
  MatDatepickerModule,
  MatFormFieldModule,
  MatInputModule,
  MatNativeDateModule,
  MatPaginatorModule,
  MatSelectModule,
  MatTableModule,
  MatCheckboxModule,
  MatTooltipModule,
  MatTabsModule
} from "@angular/material";
import { DialogDataSetComponent } from './dialog-data-set/dialog-data-set.component';
import { DatasetComponent } from './dataset/dataset.component';
import { EdaProcessingComponent } from './eda-processing/eda-processing.component';
import { FeatureExtractionComponent } from './feature-extraction/feature-extraction.component';
import { ModellingComponent } from './modelling/modelling.component';

const routes: Routes = [
  {
    path: "",
    component: UsecaseComponent,
  },
  {
    path: "usecases",
    component: UsecaseComponent,
  },
  {
    path : "history",
    component: HistoryComponent
  },
  { 
    path:"datascience",
    component: DatascienceComponent
  },
  {
    path: "dataset", 
    component: DatasetComponent
  }
];

@NgModule({
  declarations: [UsecaseComponent, ConfigComponent, HistoryComponent, DatascienceComponent, DialogDataSetComponent, DatasetComponent, EdaProcessingComponent, FeatureExtractionComponent, ModellingComponent ],
  imports: [
    CommonModule,
    FormsModule,
    FlexLayoutModule,
    Ng2SearchPipeModule,
    MatButtonModule,
    MatCardModule,
    MatDatepickerModule,
    MatFormFieldModule,
    MatInputModule,
    MatNativeDateModule,
    MatPaginatorModule,
    MatSelectModule,
    MatTableModule,
    MatCheckboxModule,
    MatDialogModule,
    MatTooltipModule,
    MatTabsModule,
    CarouselModule,
    RouterModule.forChild(routes)
  ],
  entryComponents: [DialogDataSetComponent],
})
export class DatascienceModule { }
