import { Component, OnInit, OnDestroy , ViewChild,AfterViewInit,ChangeDetectionStrategy,ChangeDetectorRef } from "@angular/core";
// import { MatTableDataSource } from "@angular/material";
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import {MatTableDataSource} from '@angular/material/table';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatDatepickerInputEvent} from '@angular/material/datepicker';
import { MatInput, MatDatepicker } from '@angular/material'
import {SelectionModel} from '@angular/cdk/collections';
import { Router } from "@angular/router";
import { DialogDataSetComponent } from 'src/app/datascience/dialog-data-set/dialog-data-set.component'
import { PdffilesService } from "src/app/Services/pdffiles.service";
import { PdfserviceService } from "src/app/Services/pdfservice.service";
import { DatascienceService } from "src/app/Services/datascience.service";
import {TooltipPosition} from '@angular/material/tooltip';

import { OwlOptions } from 'ngx-owl-carousel-o';

import * as _moment from 'moment';
import {  Moment } from 'moment';
const moment = _moment;


export interface Annotation {
  id : number;
  documentId : string,
  documentName: string;
  segmentText: string;
  segmentId : number;
  datasetName: number;
  pageNo: string;
  labelId: number;
  labelName: string,
  categoryShortName: string,
  categoryName : string,
  updateBy: string, 
  updatedOn: number,
  updateDate: Date
}
export interface DialogData {
  name: string;
  value: string;
}
let TABLE_DATA: Annotation[] = [];
@Component({
  selector: 'app-history',
  templateUrl: './history.component.html',
  styleUrls: ['./history.component.scss'],

  changeDetection: ChangeDetectionStrategy.OnPush
})
export class HistoryComponent implements OnInit, AfterViewInit, OnDestroy{
  pdfFiles: any;
  categoryList: any[] = [];
  documentName: any[];
  category: any[];
  fromDate:Date;
  toDate: Date;
  marked: boolean = true;
  notMarked: boolean = true;
  useCase: string;
  totalCount: number = 0;
  annotationData : Annotation[] = [];
  isMarked: boolean = true;
  isNotMarked: boolean = true;

  customOptions: OwlOptions = {
    loop: true,
    mouseDrag: false,
    touchDrag: false,
    pullDrag: false,
    dots: false,
    autoplay: true,
    navSpeed: 700,
    autoplayHoverPause: true,
    items: 3,
    navText: ['<', '>'],
    responsive: {
      0: {
        items: 3
      },
      400: {
        items: 3
      },
      740: {
        items: 3
      },
      940: {
        items: 3
      }
    },
    nav: false
  }
  slides = [{'image': 'https://gsr.dev/material2-carousel/assets/demo.png'}, {'image': 'https://gsr.dev/material2-carousel/assets/demo.png'},{'image': 'https://gsr.dev/material2-carousel/assets/demo.png'}, {'image': 'https://gsr.dev/material2-carousel/assets/demo.png'},
   {'image': 'https://gsr.dev/material2-carousel/assets/demo.png'}];
  public displayedColumns: string[] = [
    "select",
    "Document Name",
    "Segmant Text 3 lines",
    "Page no",
    "Category Name",
    "Updated by",
    "Updated On",
    "Data Set",
  ];
  dataSource = new MatTableDataSource<Annotation>(TABLE_DATA);
  selection = new SelectionModel<Annotation>(true, []);
  positionOptions: TooltipPosition[] = ['below', 'above', 'left', 'right'];
  // @ViewChild(MatPaginator, { static: false }) set content(
  //   paginator: MatPaginator
  // ) {
  //   this.dataSource.paginator = paginator;
  // }
   @ViewChild(MatPaginator, {static: false}) paginator: MatPaginator;
   @ViewChild(MatTableDataSource, {static: false}) table: MatTableDataSource<any>;
   @ViewChild('picker1', {static: false}) fromInput: MatDatepicker<Moment>;  
  @ViewChild('picker2', {static: false}) toInput: MatDatepicker<Moment>;
  constructor(
    private PdfserviceService: PdfserviceService,
    private PdffilesService: PdffilesService,
    private router: Router,
    private datascienceService: DatascienceService,
    private cdRef:ChangeDetectorRef,
    public dialog: MatDialog
  ) {
   }

  ngOnInit() {
    this.useCase = localStorage.getItem('useCaseId');
    let useCaseName = localStorage.getItem('useCaseName');
    this.PdfserviceService.annotation("History");
    this.PdfserviceService.setUseCaseName(useCaseName);
    this.getCategoryList();
    this.getDocumentList();
  }
  ngAfterViewInit(){
    this.getAnnotation();
    this.cdRef.detectChanges();
  }
  ngOnDestroy() {
    this.PdfserviceService.setUseCaseName("");
  }


/**
 * Get Data document list 
 * Use - Docuemnt list drop down
 * @input - empty
 */
  getDocumentList(){
   this.datascienceService.getDocument().subscribe((res: any)=> {
     if(res.statusCode = 200){
      this.pdfFiles = res.documentList;
     }else{
      this.pdfFiles = [];
     }
     
   },(err)=> {})
  }
  /**
   * Get Categories list from
   */
  getCategoryList(){
    this.datascienceService.getCategory().subscribe((res: any) =>{
      this.categoryList = res.map(s => {
        return{ ...s, count : 0}
      });
      
      this.getAnnotation();
    },(err)=>{})
  }
  /**
   * Open the model When select all time
   * @input - Data set Name
   * @output - Date set Name
   */
  openDialog(): void {
    const dialogRef = this.dialog.open(DialogDataSetComponent, {
      width: '500px',
      height: '400px',
      disableClose: true,
      data: {name: 'LNT', value: '', categories : this.categoryList, annotationData : this.annotationData}
    });
    
    dialogRef.afterClosed().subscribe(result => {
      if(!result){
        this.selection.clear();
        var data =  this.dataSource.data.forEach(row => this.selection.deselect(row));
        this.cdRef.detectChanges(); 
      }else{
        this.saveDatamark(result);
      }
     
    });
  }
 
  /**
   * Change calender values in filter
   * @param type 
   * @param event 
   */
  addEventFrom(type: string, event: MatDatepickerInputEvent<Date>) {
    this.fromDate = event.value;
  }
  addEventTo(type: string, event: MatDatepickerInputEvent<Date>) {
    this.toDate = event.value;
  }
  /**
   * Reset functionality
   */
  reset(fromInputDup, toInputDup){
    fromInputDup.value = '';
    toInputDup.value = '';
    this.fromDate = undefined;
    this.toDate = undefined;
    this.fromInput.select(undefined);
    this.toInput.select(undefined);
    this.category = undefined;
    this.documentName = undefined;  
    this.getAnnotation();
  }
  
  /**
   * @trigger - next, prev, change page size
   * @param event 
   */
  onPaginateChange(event){
    this.getAnnotation(event.pageIndex);
  }
  /**
   * Get Annonation data 
   * @param i 
   */
  getAnnotation(i = 0){
    this.selection.clear();
    var label, labelName;
    this.paginator.pageIndex = i;
    let fromDateDup = this.fromDate ? new Date(this.fromDate.getMonth() + 1 +"/" + this.fromDate.getDate() + "/" + this.fromDate.getFullYear()).getTime()  : 0;
    let toDateDup = this.toDate ? new Date(this.toDate.getMonth() + 1 +"/" + this.toDate.getDate() + "/" + this.toDate.getFullYear()).getTime() + (24 * 60* 60*1000) : 0;    
    let body = {
      documents :this.documentName,
      categories : this.category,
      totalNo : this.paginator.pageSize,
      startNo: this.paginator.pageIndex *this.paginator.pageSize,
      fromDate: fromDateDup,
      toDate : toDateDup,
      marked: this.marked,
      notMarked: this.notMarked,
      useCase: this.useCase
    }
    this.datascienceService.getAnnotation(body)
    .subscribe(
      (res) => {
        if(res.statusCode == 200){
          this.totalCount = res.total;
          this.paginator.length = res.total;
          this.annotationData = res.listAnnotations.map(obj => {
            label = this.categoryList.find(o => o.id == obj.labelId);
            labelName = label? label.name : "Non Clauses";
            return {...obj, updateDate: new Date(obj.updatedOn), categoryName: labelName}
          });
                    
          TABLE_DATA = this.annotationData;
          this.dataSource = new MatTableDataSource(TABLE_DATA);

          this.categoryList = this.categoryList.map(o => {
           var count = res.labels.find(x => x.labelId == o.id)
          return {...o, 
              count:count? count.count: 0,  toolTip : count? this.makeToolTipString(count.list,o): o.name }
               }
          );
        }
      },(err)=> {}
    )
  }

  makeToolTipString(list, obj){
    var val = obj.name;
    for(var i = 0; i < list.length; i++)
    { 
      val = val + "\n"+ list[i].datasetName + " " + list[i].count
    }
    return val;
  }


  /**
   * Add data mark in records
   * @param datamarkName 
   * 
   */
  saveDatamark(datamarkName){
    var label, labelName;
    let body = {
      dataMark : datamarkName,
      annotations : this.annotationData.filter(o => o.datasetName == null)
    }
    this.datascienceService.saveAnnotation(body)
    .subscribe(
      (res) => {
        if(res.statusCode == 200){                 
          TABLE_DATA = this.annotationData.map(obj => {
            label = this.categoryList.find(o => o.id == obj.labelId);
            labelName = label? label.name : "Non Clauses";
            return {...obj, updateDate: new Date(obj.updatedOn), categoryName: labelName, datasetName:datamarkName }
          });
          this.dataSource = new MatTableDataSource(TABLE_DATA);
          this.cdRef.detectChanges();
        }
      },(err)=> {}
    )
  }
/**
 * Download excel sheet 
 * 
 */
  downloadExcel(){
    let body = {
      dataMark : "Download",
      annotations : this.annotationData.map( o => {
        return {...o, updateDate : new Date(o.updatedOn).toLocaleDateString()}
      })
    }
    this.datascienceService.download(body)
    .subscribe(
      (res: any) => {
        this.downLoadFile(res, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")   
      },(err)=> {
        console.log(err);
      }
    )
  }

  downLoadFile(data: any, type: string) {
    let blob = new Blob([data], { type: type});
    let url = window.URL.createObjectURL(blob);
    let pwa = window.open(url);
    if (!pwa || pwa.closed || typeof pwa.closed == 'undefined') {
        alert( 'Please disable your Pop-up blocker and try again.');
    }
  }

  isSelectMarked(event){
    if(event.value ==="all")
    {
      this.marked = true;
      this.notMarked = true;
    }
    else if(event.value ==="marked")
    {
      this.marked = true;
      this.notMarked = false;
    }
    else if(event.value === "notMarked")
    {
      this.marked = false;
      this.notMarked = true;
    }
    this.getAnnotation();
  }

  isAllChecked(){
    const len = this.dataSource.data.filter(o => o.datasetName).length;
    const orLen = this.dataSource.data.length;
    return len == orLen;
  }
 /** Whether the number of selected elements matches the total number of rows. */
 isAllSelected() {  
  const numSelected = this.selection.selected.length;
  const numRows = this.dataSource.data.length;
  return numSelected === numRows;
}

/** Selects all rows if they are not all selected; otherwise clear selection. */
masterToggle() {  
  this.isAllSelected() ?
      this.selection.clear() :
      this.dataSource.data.forEach(row => this.selection.select(row));      
      if(this.isAllSelected()){
        this.openDialog();
      }
}

/** The label for the checkbox on the passed row */
  checkboxLabel(row?: Annotation): string {
    if (!row) {
      return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row.id + 1}`;
  }
  
}
