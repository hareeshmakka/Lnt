import { Component, OnInit, OnDestroy , ViewChild,AfterViewInit,ChangeDetectionStrategy,ChangeDetectorRef } from "@angular/core";
import { Router, ActivatedRoute, Params } from "@angular/router";
import {MatTableDataSource} from '@angular/material/table';
import {MatPaginator} from '@angular/material/paginator';
import {SelectionModel} from '@angular/cdk/collections';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { PdfserviceService } from "src/app/Services/pdfservice.service";
import { DatascienceService } from "src/app/Services/datascience.service";
import {TooltipPosition} from '@angular/material/tooltip';
export interface Annotation {
  id : number;
  documentId : string,
  documentName: string;
  segmentText: string;
  segmentId : number;
  datasetName: number;
  pageNo: string;
  labelId: number;
  labelName: string,
  categoryShortName: string,
  categoryName : string,
  updateBy: string, 
  updatedOn: number,
  updateDate: Date,
  ourId: number
}
let TABLE_DATA: Annotation[] = [];
@Component({
  selector: 'app-eda-processing',
  templateUrl: './eda-processing.component.html',
  styleUrls: ['./eda-processing.component.scss']
})
export class EdaProcessingComponent implements OnInit, AfterViewInit {  

	uniqueCategoryVal: string = '';
  entityData: SafeHtml;
  depandencyParse: SafeHtml;
  loadData: SafeHtml;
  annotation: any = {};
  annotationList:Annotation[] = [];
  categoryList: any[] = [];
  annotationData: Annotation[] = [];
  useCase: string ;
  datasetNameList :string[];
  category: any = {};
  categoryColumnName: string = "";  
  nGrams: string = '';
  tsneAnalysis : string = "";
  isNext: boolean = true;
  isPrev: boolean = true;
  isEntities: boolean = true;
  annotationOurId : number = 0;
  uniqueCategorySrc : string ;
  datasetNames : string;
  analyzeTextValue: string = "";
  analyzeTextDependencyParse: string = "";
  worldCloud : string = "";
  istsneNo : boolean = false;
  isCustomPreprocessed : boolean = false;
  tsneNoofGrams: string ;
  stopWords : string;
  emphasisWords: string;
  customPreProcessing: string = "";
  noOfGrams: string = "";
  filterResultsNo: string = "";
  categoryName: string = "";
  isNGramsValidate: any =
  {
    isNoOfgrams: false,
    isSelectedCategory: false,
    isFilterResultNo: false
  }
  dataSource = new MatTableDataSource<Annotation>(TABLE_DATA);
  selection = new SelectionModel<Annotation>(true, []);
  @ViewChild(MatPaginator, {static: false}) paginator: MatPaginator;
  @ViewChild(MatTableDataSource, {static: false}) table: MatTableDataSource<any>;
  positionOptions: TooltipPosition[] = ['below', 'above', 'left', 'right'];
  public displayedColumns: string[] = [
    "Segment Text",   
    "Category Name",
    "Annotated by",
    "Created On"
  ];
  constructor(
    private PdfserviceService: PdfserviceService,
    private dataScienceService: DatascienceService,
    private changeDetectorRef: ChangeDetectorRef,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private _sanitizer: DomSanitizer
  ) { 
    this.useCase = this.activatedRoute.snapshot.params["id"]
    this.datasetNameList =JSON.parse(this.activatedRoute.snapshot.params["datasets"]);
    this.datasetNames = this.datasetNameList.join(",");
  }

  ngOnInit() {
   this.getAnnotationList();
   this.getCategoryList();    
   this.getUniqueCategoriesDataCount();
  }
  ngAfterViewInit() {
    this.changeDetectorRef.detectChanges();
  }


  /**
   * @trigger - next, prev, change page size
   * @param event 
   */
  onPaginateChange(event){
    this.getAnnotation(event.pageIndex);
  }

  /**
   * Get Categories list from
   */
  getCategoryList(){
    this.dataScienceService.getCategory().subscribe((res: any) =>{
      this.categoryList = res.map(s => {
        return{ ...s, count : 0}
      });
      this.category = this.categoryList.length > 0? this.categoryList[0] : {};
      this.getAnnotation();
      this.getWordCloud();
    },(err)=>{})
  }

  /**
   * Get Annonation data 
   * @param i 
   */
  getAnnotation(i = 0){
  
    var label, labelName;
    this.paginator.pageIndex = i;   
    let body = {    
      totalNo : this.paginator.pageSize,
      startNo: this.paginator.pageIndex *this.paginator.pageSize,
      datasetNames :this.datasetNameList,
      useCase: this.useCase
    }
    this.dataScienceService.getAnnotations(body)
    .subscribe(
      (res) => {
        if(res.statusCode == 200){
          this.paginator.length = res.total;
          this.annotationData = res.listAnnotations.map(obj => {
            label = this.categoryList.find(o => o.id == obj.labelId);
            labelName = label? label.name : "Non Clauses";
            return {...obj, updateDate: new Date(obj.updatedOn), categoryName: labelName}
          });
                    
          TABLE_DATA = this.annotationData;
          this.dataSource = new MatTableDataSource(TABLE_DATA);

        //   this.categoryList = this.categoryList.map(o => {
        //    var count = res.labels.find(x => x.labelId == o.id)
        //     return {...o, 
        //         count:count? count.count: 0,  toolTip : count? this.makeToolTipString(count.list,o): o.name }
        //         }
        //     );
         }
      },(err)=> {}
    )
  }
  makeToolTipString(list, obj){
    var val = obj.name;
    for(var i = 0; i < list.length; i++)
    { 
      val = val + "\n"+ list[i].datasetName + " " + list[i].count
    }
    return val;
  }
  /**
   * Next button form Analyze text
   */
  nextAnalyzeText = () => {
    this.isPrev = false;
    this.annotationOurId = this.annotationOurId + 1;
    this.annotation = this.annotationList.find(b => b.ourId === this.annotationOurId);
    if(this.annotationList.length === this.annotationOurId)
    {
      this.isNext = true;
    }
    this.getAnalyzeTextValue();
  }
  /**
   * Previous button form Analyze text
   * Next button form Analyze text
   */
  prevAnalyzeText = () => {
    this.isNext = false;
    this.annotationOurId = this.annotationOurId - 1;
    this.annotation = this.annotationList.find(b => b.ourId === this.annotationOurId);
    if(this.annotationOurId == 1)
    {
      this.isPrev = true;
    }
    this.getAnalyzeTextValue();
  }

  getAnalyzeTextValue = () => {
    let body = {
      usecase_id: this.useCase,
      dataset_markers: this.datasetNames.split(","),
      segment_text : this.annotation.segmentText
    };
    this.dataScienceService.getAnalyzeText(body).subscribe(
      (res) => {
        if(res.status == "success")
        {
          this.analyzeTextValue = res.output;
          if(this.isEntities)
          {
            this.entityData = this._sanitizer.bypassSecurityTrustHtml(this.analyzeTextValue);
          }
        }
      },
      (error) => {
        console.log(error);
      }
    );    
    
    this.dataScienceService.getAnalyzeTextDepedencyParse(body).subscribe(
      (res) => {
         if(res.status == "success")
        {
          this.analyzeTextDependencyParse = res.output;
          if(!this.isEntities)
          {
            this.entityData = this._sanitizer.bypassSecurityTrustHtml(this.analyzeTextDependencyParse);
          }
        }
      },
      (error) => {
        console.log(error);
      }
    );
      
      if(this.isEntities)
      {
        this.entityData = this._sanitizer.bypassSecurityTrustHtml(this.analyzeTextValue);     
      }
      else
      {
        this.entityData = this._sanitizer.bypassSecurityTrustHtml(this.analyzeTextDependencyParse);       
      }
  }

  /**
   * Get annotation list
   */
  getAnnotationList = () => {
    let c = 0;
    this.annotationList =  [];
    let body = {    
      totalNo : 0,
      startNo: 0,
      datasetNames :this.datasetNameList,
      useCase: this.useCase
    }
    this.dataScienceService.getAnnotations(body).subscribe(
      (res: any) => {
        if(res.statusCode === 200) {
          this.annotationList = res.listAnnotations.map(
            obj => {
              c++;
              return {...obj,ourId : c, id: c}
            }
          );
          if(this.annotationList.length > 0){
            this.isNext = false;
          }
          this.annotation = this.annotationList.length > 0? this.annotationList[0] : {};
          this.annotationOurId = this.annotation.ourId;
          this.getAnalyzeTextValue();
        }
      },
      (err)=> {
        console.log(err);
      }
    )
    
  
    
    
  }
  /**
   * select Annotation
   */
  selectAnnotation = (name) => {
    if(name == 'entities')
    {
      this.isEntities = true;
      this.entityData = this._sanitizer.bypassSecurityTrustHtml(this.analyzeTextValue);
    }
    else{
      this.isEntities = false;
      this.entityData =this._sanitizer.bypassSecurityTrustHtml(this.analyzeTextDependencyParse);
    }
  }
  /**
   * get word cloud
   */
  getWordCloud = () => {
    console.log("This is word cloud"); 
    let body = 
    {
      "usecase_id": this.useCase.toString(),  
      "dataset_markers": this.annotationList.toString(),  
      "selected_category":this.category.name 
    }
    this.dataScienceService.getWord(body).subscribe(
      (res) => {
        if(res.status == "success")
        {
          this.worldCloud = res.output;
        }
      },
      (err) => {
        console.log(err);
      }
    )
  }


  /**
   * Get Unique categories data count 
   */
  getUniqueCategoriesDataCount(){
    let body = {
      "usecase_id": this.useCase,
      "dataset_markers": this.datasetNameList
    }
    this.dataScienceService.getUniqueCategoriesDataCount(body).subscribe(
      res => {
        if(res.status == "success")
        {
          this.uniqueCategorySrc = res.output;
        }
      },
      err => {
        console.log(err);
      }
    )    
  }


  /**
    * get N grams 
    */
   
  
  getNGrams =() => {
    let body = {
      usecase_id : this.useCase,
      dataset_markers: this.datasetNameList,
      no_of_grams: this.noOfGrams,
      filter_results_no: this.filterResultsNo,
      selected_Category: this.categoryName
    }
    if(body.no_of_grams != "" && body.filter_results_no != "" && body.selected_Category != ""){
      this.isNGramsValidate.isNoOfgrams = false;
      this.isNGramsValidate.isFilterResultNo = false;
      this.isNGramsValidate.isSelectedCategory = false;
      this.dataScienceService.getNGrams(body)
      .subscribe(
        (res) => {
          if(res.status === "success")
          {
            this.nGrams = res.output;
          }
        },
        (error) => {
          console.log(error);
        }
      );
    }
    else
    {
      if(body.no_of_grams == "")
      {
        this.isNGramsValidate.isNoOfgrams = true;
      }else{
        this.isNGramsValidate.isNoOfgrams = false;
      }
      if(body.filter_results_no == "")
      {
        this.isNGramsValidate.isFilterResultNo = true;
      }else{
        this.isNGramsValidate.isFilterResultNo = false;
      }
      if(body.selected_Category == "")
      {
        this.isNGramsValidate.isSelectedCategory = true;
      }else{
        this.isNGramsValidate.isSelectedCategory = false;
      }
    }    
  }

  /**
   * Get TSNE Analysis
   */
  getTsneAnalysis = () => {
    let body = {
      usecase_id : this.useCase,
      dataset_markers : this.datasetNameList,
      no_of_grams : this.tsneNoofGrams
    }
    if(body.no_of_grams != "" && body.no_of_grams != undefined && body.no_of_grams != null){
      this.istsneNo = false;
      this.dataScienceService.getNGrams(body).subscribe(
        (res) => {
          if(res.status == "success")
          {
            this.tsneAnalysis = res.output;
            //this.tsneNoofGrams = "";           
          }
        }
        ,(error) => {
          console.log(error);
        }
      )
    }
    else{
      this.istsneNo = true;
    }    
    
  }

  /**
    * Get Custome Pre processing
  */
  getCustomPreprocessing = () => {
    let body = {
      usecase_id: this.useCase,
      dataset_markers: this.datasetNameList,
      stopwords: this.stopWords,
      emphasized_words: this.emphasisWords
    }
    if((body.stopwords && body.stopwords.length > 0) || (body.emphasized_words && body.emphasized_words.length >0)){
      this.isCustomPreprocessed = false;
      this.dataScienceService.getCustomPreprocessing(body)
    .subscribe(
      (res) => {
        if(res.status === "success")
        {
          this.customPreProcessing = res.output;
        }
      },
      (error) => {
        console.log(error);
      }
    )
    }
    else
    {
      this.isCustomPreprocessed = true;
    }
  }


  onKeypress(event: any) {
    const keyChar = event.key;
    let allowCharacter: boolean;
    if (keyChar === "-" && event.target.selectionStart !== 0) {
      allowCharacter = false;
    }else if(keyChar === "-" )
    {
      return false;
    }else if(keyChar === "0" && event.target.value.trim() === "")
    {
      return false;
    }
    else if (
      keyChar === "Tab" ||
      keyChar === "Enter" ||
      keyChar === "Backspace" ||
      keyChar === "ArrowLeft" ||
      keyChar === "ArrowRight" ||
      keyChar === "Delete") {
      allowCharacter = true;
    }
    else {
      allowCharacter = (keyChar >= '0' && keyChar <= '9');
    }
  
    if (!allowCharacter) {
      event.preventDefault();
    }
  }

}
